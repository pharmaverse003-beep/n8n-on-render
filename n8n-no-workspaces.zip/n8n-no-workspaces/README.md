# n8n on Render (no workspaces / no pnpm)

This repo deploys **n8n** on **Render** using Docker, so you avoid npm/pnpm/workspace errors entirely.

## 4 Super-Simple Steps

**1) Push this repo to your GitHub**  
- If you downloaded a ZIP: create a new repo (e.g., `n8n-on-render`), upload these files, and push.

**2) Create Web Service on Render**  
- Render → New → Web Service → pick your repo (Dockerfile is auto-detected).  
- Region: closest to India (e.g., Singapore). Create.

**3) Set Environment Variables (Render → Environment)**  
Add:
```
N8N_BASIC_AUTH_ACTIVE=true
N8N_BASIC_AUTH_USER=admin
N8N_BASIC_AUTH_PASSWORD=choose-a-strong-password
N8N_ENCRYPTION_KEY=any-long-random-string
```
Deploy once, copy your public URL (e.g., `n8n-razorpay.onrender.com`), then add:
```
N8N_HOST=n8n-razorpay.onrender.com
WEBHOOK_URL=https://n8n-razorpay.onrender.com
```
Save → Manual Deploy → **Clear build cache & deploy**.

**4) Import the workflow into n8n & connect Razorpay**  
- Open your Render URL → log in (admin + your password).  
- Import the file `workflow/razorpay_email_workflow.json`.  
- Open the **Email Send** node and connect Gmail OAuth2 or your SMTP.  
- Copy your webhook URL: `https://YOUR_HOST/webhook/razorpay` and set it in Razorpay Dashboard → Settings → Webhooks → `payment.captured`.

## Notes
- This setup sends a **download link** by email (simplest). If you want to send an actual file attachment, add an **HTTP Request** node that downloads the file (Response → File) and attach it in the Email node using the binary property.
- To validate payments server‑side, add an **HTTP Request** node to `GET https://api.razorpay.com/v1/payments/{{ $json["payload"]["payment"]["entity"]["id"] }}` using Razorpay Key ID/Secret (Basic Auth), then check `status === "captured"` with an **IF** node before sending email.
