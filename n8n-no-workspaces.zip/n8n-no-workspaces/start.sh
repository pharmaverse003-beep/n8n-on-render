#!/usr/bin/env sh
# Render sets $PORT dynamically; pass it to n8n
export N8N_PORT="${PORT:-5678}"
export N8N_PROTOCOL="https"
# avoid losing webhooks during restarts
export N8N_SKIP_WEBHOOK_DEREGISTRATION="true"
# start n8n
n8n start
